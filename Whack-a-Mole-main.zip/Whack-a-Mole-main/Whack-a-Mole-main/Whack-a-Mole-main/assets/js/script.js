const DURACAO_NIVEL = 300; // duração de cada nível, confirmar com as meninas s é isso msm
let intervalo = null;
let jogoPausado = false;
let jogoAtivo = false;

window.addEventListener('DOMContentLoaded', () => {
    const elementoTempo = document.getElementById('time');
    if (!elementoTempo) return;

    const urlParams = new URLSearchParams(window.location.search);
    const deveRetomar = urlParams.get('retomar');
    
    const tempoSalvo = localStorage.getItem('tempoRestante');

    if (deveRetomar === 'true' && tempoSalvo !== null) {
        tempoRestante = parseInt(tempoSalvo);
    } else {
        tempoRestante = 300;
        localStorage.removeItem('tempoRestante');
    }

    iniciarTemporizador();
});

function iniciarTemporizador() {
    if (intervalo) return;
    
    jogoAtivo = true;
    jogoPausado = false;
    
    atualizarTempo();

        intervalo = setInterval(() => {
        if (!jogoPausado && jogoAtivo) {
            tempoRestante--;
            atualizarTempo();
            localStorage.setItem('tempoRestante', tempoRestante);

            if (tempoRestante <= 0) {
                fimDoNivel();
            }
        }
    }, 1000);
}

function atualizarTempo() {
    let minutos = Math.floor(tempoRestante / 60);
    let segundos = tempoRestante % 60;

    let minutosFormatados = String(minutos).padStart(2, '0');
    let segundosFormatados = String(segundos).padStart(2, '0');

    const elementoTempo = document.getElementById('time');
    if (elementoTempo) {
        elementoTempo.textContent = `${minutosFormatados}:${segundosFormatados}`;
    }
}

function pausarPartida() {
    jogoPausado = true;
    localStorage.setItem('tempoRestante', tempoRestante);
}

function retomarPartida() {
    jogoPausado = false;
}

function fimDoNivel() {
    if (placar.pontosNivel >= metaDoNivel(placar.nivel)) {
        avancarNivel();
        tempoRestante = DURACAO_NIVEL;
        atualizarTempo();
    } else {
        finalizarPartida('derrota');
    }
}

function finalizarPartida(resultado) {
    jogoAtivo = false;
    clearInterval(intervalo);
    intervalo = null;
    
    localStorage.removeItem('tempoRestante');

    if (resultado === 'derrota') {
        window.location.href = 'modal-derrota-vitoria.html#derrota';
    } else if (resultado === 'vitoria') {
        window.location.href = 'modal-derrota-vitoria.html#vitoria';
    }
}

function reiniciarPartida() {
    localStorage.removeItem('tempoRestante');
    tempoRestante = 300;
    atualizarTempo();
    iniciarTemporizador();
}