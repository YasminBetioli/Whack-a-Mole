<?php
// Configurações do banco de dados.
// Valores padrão do XAMPP: usuário "root" e senha vazia.
// Se o seu MySQL for diferente, mude só aqui.

const DB_HOST    = 'localhost';
const DB_USUARIO = 'root';
const DB_SENHA   = '';
const DB_NOME    = 'whack_a_anomaly';
