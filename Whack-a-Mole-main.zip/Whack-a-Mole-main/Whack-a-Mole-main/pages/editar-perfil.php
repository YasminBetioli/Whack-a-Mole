<?php require_once __DIR__ . '/../config/verificar_sessao.php'; ?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../assets/css/login-cadastro-perfil-home.css">
    <title> Whack-a-Anomaly | Editar Perfil </title>
</head>

<body>
    <div class="editar-perfil-page">

        <div class="container-editar-perfil">

            <div class="secao-foto">

                <div class="foto-perfil">
                    <img src="../assets/img/Foto_Perfil_Login.png" alt="Personagem como foto de perfil">
                </div>
            
            </div>

            <div class="linha-divisora"></div>

            <div class="secao-formulario">
                <h1> Editar Perfil </h1>

                <form>
                    <div class="campo-input-texto linha-completa">
                        <label for="nome"> Nome Completo </label>
                        <input type="text" id="nome" name="nome">
                        <img src="../assets/img/Icone_Lapis.png" alt="Icone de lapis">
                    </div>

                    <div class="input-segunda-linha">
                        <div class="campo-input-texto metade">
                            <label for="data-nascimento"> Data de Nascimento </label>
                            <input type="text" id="data-nascimento" name="data-nascimento" disabled>
                            <img src="../assets/img/Cadeado_Claro.png" alt="Icone de cadeado">
                        </div>

                        <div class="campo-input-texto metade input-com-cadeado">
                            <label for="cpf"> CPF </label>
                            <input type="text" id="cpf" name="cpf" disabled>
                            <img src="../assets/img/Cadeado_Claro.png" alt="Icone de cadeado">
                        </div>
                    </div>

                    <div class="input-terceira-linha">
                        <div class="campo-input-texto metade">
                            <label for="telefone"> Telefone </label>
                            <input type="tel" id="telefone" name="telefone">
                            <img src="../assets/img/Icone_Lapis.png" alt="Icone de lapis">
                        </div>

                        <div class="campo-input-texto metade">
                            <label for="email"> E-mail </label>
                            <input type="email" id="email" name="email">
                            <img src="../assets/img/Icone_Lapis.png" alt="Icone de lapis">
                        </div>
                    </div>

                    <div class="input-quarta-linha">
                        <div class="campo-input-texto metade input-com-cadeado">
                            <label for="username-cadastro"> Username </label>
                            <input type="text" id="username-cadastro" name="username-cadastro" disabled>
                            <img src="../assets/img/Cadeado_Claro.png" alt="Icone de cadeado">
                        </div>

                        <div class="campo-input-texto metade">
                            <label for="senha-cadastro"> Senha </label>
                            <input type="password" id="senha-cadastro" name="senha-cadastro">
                            <img src="../assets/img/Icone_Lapis.png" alt="Icone de lapis">
                        </div>
                    </div>

                    <div class="botoes-editar-perfil">
                        <button type="button" class="button" onclick="window.location.href='home.php'"> Salvar alterações </button>
                        <button type="button" class="button-vermelho" onclick="window.location.href='../logout.php'"> Sair da conta </button>
                    </div>


                </form>

            </div>
            
        </div>

        <img src="../assets/img/Canto_Inferior_Direito_Login.png" alt="Personagem decorativo">

    </div>
</body>
</html>

