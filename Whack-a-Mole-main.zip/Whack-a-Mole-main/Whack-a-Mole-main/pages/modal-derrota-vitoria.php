<?php require_once __DIR__ . '/../config/verificar_sessao.php'; ?>
<!doctype html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Whack-a-Anomaly</title>
    <link rel="stylesheet" href="../assets/css/derrota-vitoria.css">
    <script src="../assets/js/placar.js" defer></script>
</head>

<body>
    <main class="jogo">

        <!-- ================================================= -->
        <!-- QUADRO DE VITÓRIA                                 -->
        <!-- ================================================= -->
        <div id="vitoria" class="quadro">
            <div class="resultado">
                <!-- SELO DE TAXA DE ACERTO -->
                <div class="selo-acertos">
                    <img src="../assets/img/selo.png" alt="Taxa de acertos" class="imagem-selo">
                    <div class="porcentagem-acerto">
                        <p>Taxa de acerto</p>
                        <p id="porcentagem-vitoria">0%</p>
                    </div>
                </div>

                <!-- PONTUAÇÃO TOTAL -->
                <div class="linha-dado pontuacao">
                    <span class="etiqueta"> Pontuação: </span>
                    <div class="campo-linha">
                        <div class="valor cor-verde" id="pontuacao-vitoria">0</div>
                        <div class="linha-tracejada"></div>
                    </div>
                </div>

                <!-- NÍVEL ALCANÇADO -->
                <div class="linha-dado nivel">
                    <span class="etiqueta"> Nível atingido: </span>
                    <div class="campo-linha">
                        <div class="valor cor-azul" id="nivel-vitoria">1</div>
                        <div class="linha-tracejada"></div>
                    </div>
                </div>

                <!-- DESEMPENHO -->
                <div class="bloco-desempenho">
                    <div class="etiqueta-centro">Desempenho do hospital:</div>
                    <div class="valor-centro cor-roxa" id="desempenho-vitoria">Bom</div>
                    <div class="linha-tracejada-centro"></div>
                </div>
            </div>

            <!-- BOTAO PARA AVANÇAR DE NÍVEL -->
            <button type="button" id="btn-proximo-nivel" class="btn-proximo-nivel" onclick="window.location.href='tabuleiro.php?proximoNivel=true'">Próximo nível -&gt;</button>
        </div>

        <!-- ================================================= -->
        <!-- QUADRO DE DERROTA                                 -->
        <!-- ================================================= -->
        <div id="derrota" class="quadro" >
            <div class="resultado">
                <div class="selo-acertos">
                    <img src="../assets/img/selo.png" alt="Taxa de acertos" class="imagem-selo">
                    <div class="porcentagem-acerto">
                        <p>Taxa de acerto</p>
                        <p id="porcentagem-derrota">0%</p>
                    </div>
                </div>

                <!-- PONTUAÇÃO -->
                <div class="linha-dado pontuacao">
                    <div class="etiqueta"> Pontuação: </div>
                    <div class="campo-linha">
                        <div class="valor cor-vermelha" id="pontuacao-derrota">0</div>
                        <div class="linha-tracejada"></div>
                    </div>
                </div>

                <!-- NÍVEL -->
                <div class="linha-dado nivel">
                    <div class="etiqueta"> Nível atingido: </div>
                    <div class="campo-linha">
                        <span class="valor cor-azul" id="nivel-derrota">1</span>
                        <div class="linha-tracejada"></div>
                    </div>
                </div>

                <!-- DESEMPENHO -->
                <div style="margin-top: 10px;" class="bloco-desempenho">
                    <div class="etiqueta-centro">Desempenho do hospital:</div>
                    <div class="valor-centro cor-vermelha">
                        Você perdeu <br>tente novamente!
                    </div>
                </div>
                <div class="linha-tracejada-centro"></div>
                <img class="img-perder" src="../assets/img/monstrinho.png" alt="Monstrinho">
                
            </div>

            <button type="button" id="btn-tentar-novamente" class="btn-tentar-novamente" onclick="localStorage.clear(); window.location.href='home.php?abrirModal=true'"> Tentar novamente </button> 
            
        </div>
    </main>

    <script src="../assets/js/derrota-vitoria.js"></script>
</body>

</html>