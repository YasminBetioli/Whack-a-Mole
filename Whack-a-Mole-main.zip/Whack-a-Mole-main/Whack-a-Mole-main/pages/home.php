<?php require_once __DIR__ . '/../config/verificar_sessao.php'; ?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Whack-a-Anomaly | Início </title>
    
    <link rel="stylesheet" href="../assets/css/login-cadastro-perfil-home.css">
    <link rel="stylesheet" href="../assets/css/modo-jogo.css">
</head>

<body>
    <div class="menu-page">
        <div class="menu-container">
            
            <img src="../assets/img/Logo_Principal_Jogo.png" alt="Whack-a-Anomaly Logo" class="logo-menu">
            
            <div class="menu-botoes">
                
                <button type="button" class="btn-menu btn-jogar" id="abrir-selecao-jogo">Jogar</button>
                
                <button type="button" class="btn-menu" onclick="window.location.href='editar-perfil.php'">
                    <img src="../assets/img/Lapis_Verde_Escuro.png" alt="Editar Perfil">
                    Editar Perfil
                </button>
                
                <button type="button" class="btn-menu" onclick="window.location.href='ranking.php'">
                    <img src="../assets/img/Trofeu_Verde_Escuro.png" alt="Ranking Global">
                    Ranking Global
                </button>
                
                <button type="button" class="btn-menu" onclick="window.location.href='historico.php'">
                    <img src="../assets/img/Historico_Verde_Escuro.png" alt="Histórico">
                    Histórico
                </button>

                <button type="button" class="btn-menu" onclick="window.location.href='../logout.php'">
                    Sair da conta
                </button>
                
            </div>
        </div>
    </div>

    <dialog id="selecao-jogo" aria-label="Escolha do modo de jogo">
        <div id="borda">
            <div id="bordaMenor">
                <div id="content">
                    <button type="button" class="btn-voltar" aria-label="Fechar seleção">←</button>

                    <h1>Escolha o modo de jogo</h1>
                    <div id="gameMode">
                        <div id="classico">
                            <button id="modoClassicoBtn" type="button">
                                <img src="../assets/img/xicaraBranca.png" alt="imagem png de três xícaras" id="xicara">
                                Clássico
                            </button>
                        </div>
                        <div id="explosivo">
                            <button id="modoExplosivoBtn" type="button">
                                <img src="../assets/img/stalker.png" id="stalker" alt="">
                                Explosivo
                            </button>
                        </div>
                    </div>

                    <div id="opcoesBaixo">
                        <div id="tabuleiro">
                            <h2>Escolha seu tabuleiro</h2>
                            <select name="tabuleiro" id="tabuleiroSelect">
                                <option value="2x2">2x2</option>
                                <option value="3x3">3x3</option>
                                <option value="4x4">4x4</option>
                                <option value="5x5">5x5</option>
                                <option value="6x6">6x6</option>
                                <option value="7x7">7x7</option>
                                <option value="8x8">8x8</option>
                            </select>
                        </div>

                        <div class="jogar">
                            <button class="btnJogar" id="iniciar-partida" type="button">Jogar</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </dialog>

    <script src="../assets/js/interface.js"></script>

</body>
</html>